package ejercicio_patternMatcher;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main {
    public static void main(String[] args) {

        // --- EJERCICIO 1 ---
        // Explicación: Permite letras (incluyendo tildes) y números en cualquier orden.
        System.out.println("EJERCICIO 1: Palabras con letras y números");
        Pattern patron1 = Pattern.compile("^[a-zA-Z0-9áéíóúÁÉÍÓÚ]+$");
        String cadenas1 = "Colombia Quito Venezuela2 Braz1l 25Perú @Inválido";
        String[] palabras1 = cadenas1.split("\\s");
        for (String p : palabras1) {
            Matcher analisis = patron1.matcher(p);
            if (analisis.find()) {
                System.out.println("Válido: " + analisis.group());
            }
        }

        // --- EJERCICIO 2 ---
        // Explicación: IPs de 0.0.0.0 a 255.255.255.255
        System.out.println("\nEJERCICIO 2: Direcciones IP");
        Pattern patron2 = Pattern.compile("^((25[0-5]|2[0-4][0-9]|[0-1]?\\d{1,2})\\.){3}(25[0-5]|2[0-4][0-9]|[0-1]?\\d{1,2})$");
        String cadenas2 = "172.165.0.1 214.124.100.0 10.10.10.10 192.168.1.2 300.0.0.1";
        for (String p : cadenas2.split("\\s")) {
            Matcher analisis = patron2.matcher(p);
            if (analisis.find()) {
                System.out.println("Válido: " + analisis.group());
            }
        }

        // --- EJERCICIO 3 ---
        // Explicación: URLs con protocolos específicos y dominio
        System.out.println("\nEJERCICIO 3: URLs (https, http, ftp)");
        Pattern patron3 = Pattern.compile("^(https|http|ftp)://[a-z0-9.-]+\\.[a-z]{2,6}$");
        String cadenas3 = "https://www.ups.edu.ec http://google.com ftp://repositorio.net error://url";
        for (String p : cadenas3.split("\\s")) {
            Matcher analisis = patron3.matcher(p);
            if (analisis.find()) {
                System.out.println("Válido: " + analisis.group());
            }
        }

        // --- EJERCICIO 4 ---
        // Explicación: Formato exacto (xx)-xxxx-xxx
        System.out.println("\nEJERCICIO 4: Teléfonos (09)-7145-412");
        Pattern patron4 = Pattern.compile("^\\(\\d{2}\\)-\\d{4}-\\d{3}$");
        String cadenas4 = "(09)-7145-412 (08)-1422-251 (06)-1254-254 09-123-123";
        for (String p : cadenas4.split("\\s")) {
            Matcher analisis = patron4.matcher(p);
            if (analisis.find()) {
                System.out.println("Válido: " + analisis.group());
            }
        }

        // --- EJERCICIO 5 ---
        // Explicación: Hexadecimal de 4 dígitos usando solo A-F y números
        System.out.println("\nEJERCICIO 5: Hexadecimal [0-9A-F] de 4 dígitos");
        Pattern patron5 = Pattern.compile("^[0-9A-F]{4}$");
        String cadenas5 = "01AA B5CF FFFF BBCF 123G HHHH";
        for (String p : cadenas5.split("\\s")) {
            Matcher analisis = patron5.matcher(p);
            if (analisis.find()) {
                System.out.println("Válido: " + analisis.group());
            }
        }

        // --- EJERCICIO 6 ---
        // Explicación: Números (+/-) con máximo 3 decimales
        System.out.println("\nEJERCICIO 6: Números enteros/decimales (max 3)");
        Pattern patron6 = Pattern.compile("^-?\\d+(\\.\\d{1,3})?$");
        String cadenas6 = "3 -5 2.45 -45.45 45458.254 10.12345";
        for (String p : cadenas6.split("\\s")) {
            Matcher analisis = patron6.matcher(p);
            if (analisis.find()) {
                System.out.println("Válido: " + analisis.group());
            }
        }

        // --- EJERCICIO 7 ---
        // Explicación: Atributo href seguido de URL o ruta de archivo
        System.out.println("\nEJERCICIO 7: href=URL/Ruta");
        Pattern patron7 = Pattern.compile("^href=([a-z0-9.-]+\\.[a-z]{2,6}|/[a-z0-9./_-]+)$");
        String cadenas7 = "href=www.images.com.net href=/img/fto.jpg src=/img/fto.jpg";
        for (String p : cadenas7.split("\\s")) {
            Matcher analisis = patron7.matcher(p);
            if (analisis.find()) {
                System.out.println("Válido: " + analisis.group());
            }
        }

        // --- EJERCICIO 8 ---
        // Explicación: Debe tener una 'm' intermedia y terminar en 's'
        System.out.println("\nEJERCICIO 8: Tiene 'm' y termina en 's'");
        Pattern patron8 = Pattern.compile("^[a-záéíóú]*m[a-záéíóú]*s$");
        String cadenas8 = "camas tambores románticas mesas casas";
        for (String p : cadenas8.split("\\s")) {
            Matcher analisis = patron8.matcher(p);
            if (analisis.find()) {
                System.out.println("Válido: " + analisis.group());
            }
        }

        // --- EJERCICIO 9 ---
        // Explicación: Formato (+|-) regional-###-####. Códigos: 593, 591, 549...
        System.out.println("\nEJERCICIO 9: Teléfono Latam (+|-)###-###-####");
        Pattern patron9 = Pattern.compile("^[+-](593|591|549|551|571|569)-\\d{3}-\\d{4}$");
        String cadenas9 = "+593-983-3334 -591-224-5678 +100-222-3333";
        for (String p : cadenas9.split("\\s")) {
            Matcher analisis = patron9.matcher(p);
            if (analisis.find()) {
                System.out.println("Válido: " + analisis.group());
            }
        }

        // --- EJERCICIO 10 ---
        // Explicación: Valida si contiene al menos uno de los caracteres: -, /, ?, &, #, *
        System.out.println("\nEJERCICIO 10: Contiene caracteres especiales");
        Pattern patron10 = Pattern.compile(".*[-/?&#*].*");
        String cadenas10 = "hola-mundo ruta/archivo ¿id? A&B gato";
        for (String p : cadenas10.split("\\s")) {
            Matcher analisis = patron10.matcher(p);
            if (analisis.find()) {
                System.out.println("Válido: " + analisis.group());
            }
        }
    }
}